feat.mat: includes the entropy level I computed from TMB map

pid_pred_gt: includes TMB levels (automatic predictions and ground truths)