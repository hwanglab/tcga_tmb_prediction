1.low_tmb_gt.png

low tmb & high entropy vs low tmb & low entropy
(low tmb is the ground truth using wex)

2.low_tmb_pred.png

low tmb & high entropy vs low tmb & low entropy
(low tmb is the automatically predicted low tmb)


3.gt_heatmap_high.png

wex high & high entropy vs wex low & high entropy

4.pred_heatmap_high.png

predicted high & high entropy vs predicted low & high entropy