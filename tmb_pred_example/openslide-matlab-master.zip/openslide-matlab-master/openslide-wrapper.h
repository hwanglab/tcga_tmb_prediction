#ifndef MATLAB_OPENSLIDE_WRAPPER_H
#define MATLAB_OPENSLIDE_WRAPPER_H
#define OPENSLIDE_SIMPLIFY_HEADERS
#include "E:\Hongming\projects\tcga-bladder-mutationburden\tcga_tmb_prediction\tmb_pred_example\openslide-matlab-master\openslide-win64-20160717\include\openslide\openslide.h"
#endif
